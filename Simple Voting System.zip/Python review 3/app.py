from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import json
import os

app = Flask(__name__)
app.secret_key = 'voting_system_secret_key_2024'

# Data file for storing votes
DATA_FILE = 'votes.json'

# Simple user database (Roll Number: Password/Name)
# Format: 'ROLL_NUMBER': 'STUDENT_NAME'
USERS = {
    # Admin access - Only this user can view results
    'TRISHNA': '2008',
    'admin': 'admin123',
    
    # IT Department Students
    '251T115': 'ABISHEK S',
    '2517066': 'ABUL KALAM N',
    '2511099': 'AKILESH AATHITHYA M',
    '2517053': 'ARUNDHATHI S',
    '251T100': 'ASWIN MR',
    '251T076': 'DEEPIKA N',
    '251T005': 'DHAARUNESH M',
    '251T094': 'DHARANI M',
    '2511079': 'DHARANIKA R',
    '251T085': 'DHARSHINI K',
    '251T049': 'DIYASRE K',
    '251T101': 'HARIPRASATH D',
    '251T113': 'HARSHITHAA PA',
    '251T015': 'HARSH P',
    '251T045': 'JANANI R',
    '251T052': 'KAMALESH S',
    '251T083': 'NIVETHIKA M',
    '251T070': 'PRAVEEN KUMAR V',
    '251T019': 'SAMPREETHA V S',
    '251T034': 'SANJAYVIGNESH B',
    '251T018': 'SATHISH KUMAR P',
    '251T039': 'SRI VARSHAN V',
    '251T107': 'SUBALAKSHMIR T',
    '251T041': 'YASWANTHASS',
    '2511074': 'YOSNA W',
    
    # CSE Department Students
    '25CS186': 'AISHWARYA S',
    '25CS177': 'ANISH PRANAV S',
    '25CS168': 'BINSHA B',
    '25CS115': 'DEEPAK S',
    '25CS197': 'DHARANITHARAN M',
    '25CS038': 'DHARSHINI MADHESWARAN',
    '25CS008': 'JAISHREE KEERTHANA E',
    '25CS015': 'JAISRI N',
    '25CS001': 'JAYANTH SR',
    '25CS077': 'JOHITH PRAJIN A',
    '25CS022': 'KAVIN M',
    '25CS110': 'KAVIYADHARSHIKA S',
    '25CS121': 'KRISHNUR K',
    '25CS128': 'LAKSANA S',
    '25CS184': 'NETHRA S',
    '25CS099': 'NIRANJANIKA M',
    '25CS098': 'NITHERSHANA M',
    '25CS054': 'POOVITHA C',
    '25CS041': 'PRATEEKA M',
    '25CS083': 'PREMKUMAR PP',
    '25CS062': 'PRIYANKAA J',
    '25CS130': 'RAJASRI R',
    '25CS187': 'SARAN B',
    '25CS097': 'SOWMITHA RM',
    '25CS138': 'SUBASHINE J',
    '25CS118': 'SUPRIYA S',
    '25CS148': 'SWETHA RJ',
    '25CS027': 'TRISHNA S',
    '25CS102': 'VARSAN SHREE S',
    
    # CSE(CS) Department Students
    '25SC071': 'MADHU MITHRA G',
    '25SC075': 'NIGAZHYA R',
    '25SC069': 'PRASHANT S',
    '25SC047': 'KAMALESH K',
    '25SC037': 'PRAVEEN N',
    '25SC028': 'LOKITSS',
    '25SC073': 'RITHICK S',
    '25SC066': 'VISHNU V',
    
    # Additional students from the list
    'A201': 'ABISHEK S',
    'A202': 'ABUL KALAM N',
    'A203': 'AISHWARYA S',
    'A204': 'AKILESH AATHITHYA M',
    'A205': 'ANISH PRANAV S',
    'A206': 'ARUNDHATHI S',
    'A207': 'ASWIN MR',
    'A208': 'BINSHA B',
    'A209': 'DEEPAK S',
    'A210': 'DEEPIKA N',
    'A211': 'DHAARUNESH M',
    'A212': 'DHARANI M',
    'A213': 'DHARANIKA R',
    'A214': 'DHARANITHARAN M',
    'A215': 'DHARSHINI K',
    'A216': 'DHARSHINI MADHESWARAN',
    'A217': 'DIYASRE K',
    'A218': 'HARIPRASATH D',
    'A219': 'HARSHITHAA PA',
    'A220': 'HARSH P',
    'A221': 'JAISHREE KEERTHANA E',
    'A222': 'JAISRI N',
    'A223': 'JANANI R',
    'A224': 'JAYANTH SR',
    'A225': 'JOHITH PRAJIN A',
    'A226': 'KAMALESH K',
    'A227': 'KAMALESH S',
    'A228': 'KAVIN M',
    'A229': 'KAVIYADHARSHIKA S',
    'A230': 'KRISHNUR K',
    'A231': 'LAKSANA S',
    'A232': 'LOKITSS',
    'A233': 'MADHU MITHRA G',
    'A234': 'MANIMEGALAI R',
    'A235': 'NETHRA S',
    'A236': 'NIGAZHYA R',
    'A237': 'NIRANJANIKA M',
    'A238': 'NITHERSHANA M',
    'A239': 'NIVETHIKA M',
    'A240': 'POOVITHA C',
    'A241': 'PRASHANT S',
    'A242': 'PRATEEKA M',
    'A243': 'PRAVEEN KUMAR V',
    'A244': 'PRAVEEN N',
    'A245': 'PREMKUMAR PP',
    'A246': 'PRIYANKAA J',
    'A247': 'RAJASRI R',
    'A248': 'RITHICK S',
    'A249': 'SAMPREETHA V S',
    'A250': 'SANJAYVIGNESH B',
    'A251': 'SARAN B',
    'A252': 'SATHISH KUMAR P',
    'A253': 'SOWMITHA RM',
    'A254': 'SRI VARSHAN V',
    'A255': 'SUBALAKSHMIR T',
    'A256': 'SUBASHINE J',
    'A257': 'SUPRIYA S',
    'A258': 'SWETHA RJ',
    'A259': 'TRISHNA S',
    'A260': 'VARSAN SHREE S',
    'A261': 'VISHNU V',
    'A262': 'YASWANTHASS',
    'A263': 'YOSNA W'
}

# Candidates data with symbols - IPL Teams
candidates = {
    'csk': {
        'name': 'Chennai Super Kings',
        'symbol': '🦁',
        'color': '#fdb913',
        'votes': 0
    },
    'rcb': {
        'name': 'Royal Challengers Bangalore',
        'symbol': '👑',
        'color': '#ec1c24',
        'votes': 0
    },
    'mi': {
        'name': 'Mumbai Indians',
        'symbol': '🔵',
        'color': '#004ba0',
        'votes': 0
    },
    'rr': {
        'name': 'Rajasthan Royals',
        'symbol': '🏰',
        'color': '#ff0080',
        'votes': 0
    }
}

def load_votes():
    """Load votes from file"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            data = json.load(f)
            for key in candidates:
                if key in data:
                    candidates[key]['votes'] = data[key]

def save_votes():
    """Save votes to file"""
    data = {key: candidates[key]['votes'] for key in candidates}
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f)

@app.route('/')
def login():
    """Login page"""
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def do_login():
    """Handle login"""
    username = request.form.get('username')
    password = request.form.get('password')
    
    if username in USERS and USERS[username] == password:
        session['username'] = username
        session['has_voted'] = False
        return jsonify({'success': True, 'redirect': '/vote'})
    return jsonify({'success': False, 'message': 'Invalid username or password!'})

@app.route('/vote')
def voting_page():
    """Voting page - requires login"""
    if 'username' not in session:
        return redirect('/')
    if session.get('has_voted'):
        return redirect('/results')
    load_votes()
    return render_template('vote.html', candidates=candidates, username=session['username'])

@app.route('/cast_vote', methods=['POST'])
def cast_vote():
    """Handle vote submission"""
    if 'username' not in session:
        return jsonify({'success': False, 'message': 'Please login first!'})
    
    if session.get('has_voted'):
        return jsonify({'success': False, 'message': 'You have already voted!'})
    
    candidate_id = request.form.get('candidate')
    
    if not candidate_id:
        return jsonify({'success': False, 'message': 'No candidate selected!'})
    
    if candidate_id in candidates:
        candidates[candidate_id]['votes'] += 1
        save_votes()
        session['has_voted'] = True
        session['voted_for'] = candidate_id
        return jsonify({'success': True, 'message': 'Vote recorded successfully!'})
    
    return jsonify({'success': False, 'message': 'Invalid candidate'})

@app.route('/result')
@app.route('/results')
def results_page():
    """Results page - Admin only"""
    # Check if user is logged in
    if 'username' not in session:
        return redirect('/')
    
    # Check if user is TRISHNA or admin (only these can view results)
    if session.get('username') not in ['TRISHNA', 'admin']:
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Access Denied</title>
            <style>
                body {
                    font-family: 'Poppins', sans-serif;
                    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                }
                .access-denied {
                    background: white;
                    padding: 50px;
                    border-radius: 20px;
                    text-align: center;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                }
                .icon { font-size: 80px; margin-bottom: 20px; }
                h1 { color: #e74c3c; margin-bottom: 10px; }
                p { color: #666; margin-bottom: 30px; }
                a {
                    display: inline-block;
                    padding: 12px 30px;
                    background: #667eea;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: 600;
                }
                a:hover { background: #5a6fd6; }
            </style>
        </head>
        <body>
            <div class="access-denied">
                <div class="icon">🚫</div>
                <h1>Access Denied</h1>
                <p>Only admin can view the results page.</p>
                <a href="/vote">Go to Voting Page</a>
            </div>
        </body>
        </html>
        """, 403
    
    load_votes()
    total_votes = sum(c['votes'] for c in candidates.values())
    
    # Calculate percentages
    results_data = {}
    for key, candidate in candidates.items():
        percentage = (candidate['votes'] / total_votes * 100) if total_votes > 0 else 0
        results_data[key] = {
            'name': candidate['name'],
            'symbol': candidate['symbol'],
            'votes': candidate['votes'],
            'percentage': round(percentage, 1),
            'color': candidate['color']
        }
    
    # Find winner
    winner = max(results_data.items(), key=lambda x: x[1]['votes']) if total_votes > 0 else None
    
    return render_template('results.html', 
                         candidates=results_data, 
                         total_votes=total_votes,
                         winner=winner,
                         username=session.get('username'))

@app.route('/api/results')
def api_results():
    """Get current results as JSON"""
    load_votes()
    total_votes = sum(c['votes'] for c in candidates.values())
    results_data = {}
    for key, candidate in candidates.items():
        percentage = (candidate['votes'] / total_votes * 100) if total_votes > 0 else 0
        results_data[key] = {
            'name': candidate['name'],
            'symbol': candidate['symbol'],
            'votes': candidate['votes'],
            'percentage': round(percentage, 1),
            'color': candidate['color']
        }
    return jsonify({'candidates': results_data, 'total_votes': total_votes})

@app.route('/reset', methods=['POST'])
def reset():
    """Reset all votes (for admin purposes)"""
    for key in candidates:
        candidates[key]['votes'] = 0
    save_votes()
    session.clear()
    return jsonify({'success': True, 'message': 'Votes reset successfully!'})

@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    load_votes()
    app.run(debug=True, host='0.0.0.0', port=5000)
